# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_pagesnMGRHW.ui'
##
## Created by: Qt User Interface Compiler version 5.14.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from qt_core import *


class Ui_MainPages(object):
    def setupUi(self, MainPages):
        if MainPages.objectName():
            MainPages.setObjectName(u"MainPages")
        MainPages.resize(860, 597)
        self.main_pages_layout = QVBoxLayout(MainPages)
        self.main_pages_layout.setSpacing(0)
        self.main_pages_layout.setObjectName(u"main_pages_layout")
        self.main_pages_layout.setContentsMargins(5, 5, 5, 5)
        self.pages = QStackedWidget(MainPages)
        self.pages.setObjectName(u"pages")
        self.champions_page = QWidget()
        self.champions_page.setObjectName(u"champions_page")
        font = QFont()
        font.setPointSize(8)
        self.champions_page.setFont(font)
        self.champions_page.setStyleSheet(u"")
        self.champions_page_layout = QVBoxLayout(self.champions_page)
        self.champions_page_layout.setSpacing(0)
        self.champions_page_layout.setObjectName(u"champions_page_layout")
        self.searchbar_frame_wrap = QFrame(self.champions_page)
        self.searchbar_frame_wrap.setObjectName(u"searchbar_frame_wrap")
        self.searchbar_frame_wrap.setMinimumSize(QSize(0, 50))
        self.searchbar_frame_wrap.setMaximumSize(QSize(16777215, 50))
        self.searchbar_frame_wrap.setFrameShape(QFrame.StyledPanel)
        self.searchbar_frame_wrap.setFrameShadow(QFrame.Raised)
        self.searchbar_frame_wrap_layout = QGridLayout(self.searchbar_frame_wrap)
        self.searchbar_frame_wrap_layout.setSpacing(0)
        self.searchbar_frame_wrap_layout.setObjectName(u"searchbar_frame_wrap_layout")
        self.searchbar_frame_wrap_layout.setContentsMargins(0, 0, 0, 0)
        self.searchbar_frame = QFrame(self.searchbar_frame_wrap)
        self.searchbar_frame.setObjectName(u"searchbar_frame")
        self.searchbar_frame.setMinimumSize(QSize(0, 50))
        self.searchbar_frame.setMaximumSize(QSize(800, 50))
        self.searchbar_frame.setFont(font)
        self.searchbar_frame.setFrameShape(QFrame.StyledPanel)
        self.searchbar_frame.setFrameShadow(QFrame.Raised)
        self.searchbar_frame_layout = QVBoxLayout(self.searchbar_frame)
        self.searchbar_frame_layout.setObjectName(u"searchbar_frame_layout")
        self.searchbar_frame_layout.setContentsMargins(0, 0, 0, 0)

        self.searchbar_frame_wrap_layout.addWidget(self.searchbar_frame, 0, 0, 1, 1)


        self.champions_page_layout.addWidget(self.searchbar_frame_wrap)

        self.filter_frame_wrap = QFrame(self.champions_page)
        self.filter_frame_wrap.setObjectName(u"filter_frame_wrap")
        self.filter_frame_wrap.setMinimumSize(QSize(0, 35))
        self.filter_frame_wrap.setMaximumSize(QSize(16777215, 35))
        self.filter_frame_wrap.setFrameShape(QFrame.StyledPanel)
        self.filter_frame_wrap.setFrameShadow(QFrame.Raised)
        self.filter_frame_wrap_layout = QGridLayout(self.filter_frame_wrap)
        self.filter_frame_wrap_layout.setObjectName(u"filter_frame_wrap_layout")
        self.filter_frame_wrap_layout.setHorizontalSpacing(0)
        self.filter_frame_wrap_layout.setContentsMargins(0, 0, 0, 0)
        self.filter_frame = QFrame(self.filter_frame_wrap)
        self.filter_frame.setObjectName(u"filter_frame")
        self.filter_frame.setMinimumSize(QSize(0, 35))
        self.filter_frame.setMaximumSize(QSize(800, 35))
        self.filter_frame.setFrameShape(QFrame.StyledPanel)
        self.filter_frame.setFrameShadow(QFrame.Raised)
        self.filter_frame_layout = QHBoxLayout(self.filter_frame)
        self.filter_frame_layout.setSpacing(6)
        self.filter_frame_layout.setObjectName(u"filter_frame_layout")
        self.filter_frame_layout.setContentsMargins(0, 0, 0, 0)

        self.filter_frame_wrap_layout.addWidget(self.filter_frame, 0, 0, 1, 1)


        self.champions_page_layout.addWidget(self.filter_frame_wrap)

        self.scroll_area_champions_page = QScrollArea(self.champions_page)
        self.scroll_area_champions_page.setObjectName(u"scroll_area_champions_page")
        self.scroll_area_champions_page.setStyleSheet(u"background: transparent;")
        self.scroll_area_champions_page.setFrameShape(QFrame.NoFrame)
        self.scroll_area_champions_page.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area_champions_page.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area_champions_page.setWidgetResizable(True)
        self.contents_champions_page = QWidget()
        self.contents_champions_page.setObjectName(u"contents_champions_page")
        self.contents_champions_page.setGeometry(QRect(0, 0, 832, 484))
        self.contents_champions_page.setFont(font)
        self.contents_champions_page.setStyleSheet(u"background: transparent;")
        self.contents_champions_page_layout = QVBoxLayout(self.contents_champions_page)
        self.contents_champions_page_layout.setSpacing(15)
        self.contents_champions_page_layout.setObjectName(u"contents_champions_page_layout")
        self.contents_champions_page_layout.setContentsMargins(5, 5, 5, 5)
        self.champion_table_frame_wrap = QFrame(self.contents_champions_page)
        self.champion_table_frame_wrap.setObjectName(u"champion_table_frame_wrap")
        self.champion_table_frame_wrap.setFrameShape(QFrame.StyledPanel)
        self.champion_table_frame_wrap.setFrameShadow(QFrame.Raised)
        self.champion_table_frame_wrap_layout = QGridLayout(self.champion_table_frame_wrap)
        self.champion_table_frame_wrap_layout.setObjectName(u"champion_table_frame_wrap_layout")
        self.champion_table_frame_wrap_layout.setContentsMargins(0, 0, 0, 0)
        self.champion_table_frame = QFrame(self.champion_table_frame_wrap)
        self.champion_table_frame.setObjectName(u"champion_table_frame")
        self.champion_table_frame.setMinimumSize(QSize(800, 200))
        self.champion_table_frame.setMaximumSize(QSize(800, 1000))
        self.champion_table_frame.setFrameShape(QFrame.StyledPanel)
        self.champion_table_frame.setFrameShadow(QFrame.Raised)
        self.champion_table_frame_layout = QVBoxLayout(self.champion_table_frame)
        self.champion_table_frame_layout.setObjectName(u"champion_table_frame_layout")
        self.champion_table_frame_layout.setContentsMargins(0, 0, 0, 0)

        self.champion_table_frame_wrap_layout.addWidget(self.champion_table_frame, 0, 0, 1, 1)


        self.contents_champions_page_layout.addWidget(self.champion_table_frame_wrap)

        self.scroll_area_champions_page.setWidget(self.contents_champions_page)

        self.champions_page_layout.addWidget(self.scroll_area_champions_page)

        self.pages.addWidget(self.champions_page)
        self.aram_page = QWidget()
        self.aram_page.setObjectName(u"aram_page")
        self.aram_page_layout = QVBoxLayout(self.aram_page)
        self.aram_page_layout.setSpacing(5)
        self.aram_page_layout.setObjectName(u"aram_page_layout")
        self.aram_page_layout.setContentsMargins(5, 5, 5, 5)
        self.scroll_area_aram_page = QScrollArea(self.aram_page)
        self.scroll_area_aram_page.setObjectName(u"scroll_area_aram_page")
        self.scroll_area_aram_page.setStyleSheet(u"background: transparent;")
        self.scroll_area_aram_page.setFrameShape(QFrame.NoFrame)
        self.scroll_area_aram_page.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area_aram_page.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area_aram_page.setWidgetResizable(True)
        self.contents_aram_page = QWidget()
        self.contents_aram_page.setObjectName(u"contents_aram_page")
        self.contents_aram_page.setGeometry(QRect(0, 0, 840, 577))
        self.contents_aram_page.setStyleSheet(u"background: transparent;")
        self.contents_aram_page_layout = QVBoxLayout(self.contents_aram_page)
        self.contents_aram_page_layout.setObjectName(u"contents_aram_page_layout")
        self.aram_table_frame_wrap = QFrame(self.contents_aram_page)
        self.aram_table_frame_wrap.setObjectName(u"aram_table_frame_wrap")
        self.aram_table_frame_wrap.setFrameShape(QFrame.StyledPanel)
        self.aram_table_frame_wrap.setFrameShadow(QFrame.Raised)
        self.aram_table_frame_wrap_layout = QGridLayout(self.aram_table_frame_wrap)
        self.aram_table_frame_wrap_layout.setObjectName(u"aram_table_frame_wrap_layout")
        self.aram_table_frame_wrap_layout.setContentsMargins(0, 0, 0, 0)
        self.aram_table_frame = QFrame(self.aram_table_frame_wrap)
        self.aram_table_frame.setObjectName(u"aram_table_frame")
        self.aram_table_frame.setMinimumSize(QSize(800, 200))
        self.aram_table_frame.setMaximumSize(QSize(800, 1000))
        self.aram_table_frame.setFrameShape(QFrame.StyledPanel)
        self.aram_table_frame.setFrameShadow(QFrame.Raised)
        self.aram_table_frame_layout = QVBoxLayout(self.aram_table_frame)
        self.aram_table_frame_layout.setObjectName(u"aram_table_frame_layout")
        self.aram_table_frame_layout.setContentsMargins(0, 0, 0, 0)

        self.aram_table_frame_wrap_layout.addWidget(self.aram_table_frame, 0, 0, 1, 1)


        self.contents_aram_page_layout.addWidget(self.aram_table_frame_wrap)

        self.scroll_area_aram_page.setWidget(self.contents_aram_page)

        self.aram_page_layout.addWidget(self.scroll_area_aram_page)

        self.pages.addWidget(self.aram_page)
        self.main_page = QWidget()
        self.main_page.setObjectName(u"main_page")
        self.main_page.setStyleSheet(u"QFrame {\n"
"	font-size: 16pt;\n"
"}")
        self.verticalLayout_3 = QVBoxLayout(self.main_page)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.scroll_area_main_page = QScrollArea(self.main_page)
        self.scroll_area_main_page.setObjectName(u"scroll_area_main_page")
        self.scroll_area_main_page.setStyleSheet(u"background: transparent;")
        self.scroll_area_main_page.setFrameShape(QFrame.NoFrame)
        self.scroll_area_main_page.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area_main_page.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area_main_page.setWidgetResizable(True)
        self.contents_main_page = QWidget()
        self.contents_main_page.setObjectName(u"contents_main_page")
        self.contents_main_page.setGeometry(QRect(0, 0, 832, 569))
        self.contents_main_page.setStyleSheet(u"background: transparent;")
        self.contents_main_page_layout = QVBoxLayout(self.contents_main_page)
        self.contents_main_page_layout.setObjectName(u"contents_main_page_layout")
        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.contents_main_page_layout.addItem(self.verticalSpacer_2)

        self.summoner_info_frame = QFrame(self.contents_main_page)
        self.summoner_info_frame.setObjectName(u"summoner_info_frame")
        self.summoner_info_frame.setMinimumSize(QSize(0, 0))
        self.summoner_info_frame.setMaximumSize(QSize(16777215, 16777215))
        font1 = QFont()
        font1.setPointSize(16)
        self.summoner_info_frame.setFont(font1)
        self.summoner_info_frame.setFrameShape(QFrame.StyledPanel)
        self.summoner_info_frame.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.summoner_info_frame)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.loading_frame = QFrame(self.summoner_info_frame)
        self.loading_frame.setObjectName(u"loading_frame")
        self.loading_frame.setFrameShape(QFrame.StyledPanel)
        self.loading_frame.setFrameShadow(QFrame.Raised)
        self.loading_frame_layout = QGridLayout(self.loading_frame)
        self.loading_frame_layout.setSpacing(0)
        self.loading_frame_layout.setObjectName(u"loading_frame_layout")
        self.loading_frame_layout.setContentsMargins(0, 20, 0, 0)

        self.gridLayout.addWidget(self.loading_frame, 3, 0, 1, 1)

        self.chest_info_frame_wrap = QFrame(self.summoner_info_frame)
        self.chest_info_frame_wrap.setObjectName(u"chest_info_frame_wrap")
        self.chest_info_frame_wrap.setMinimumSize(QSize(100, 30))
        self.chest_info_frame_wrap.setMaximumSize(QSize(16777215, 16777215))
        self.chest_info_frame_wrap.setFrameShape(QFrame.StyledPanel)
        self.chest_info_frame_wrap.setFrameShadow(QFrame.Raised)
        self.chest_info_frame_wrap_layout = QGridLayout(self.chest_info_frame_wrap)
        self.chest_info_frame_wrap_layout.setObjectName(u"chest_info_frame_wrap_layout")
        self.chest_info_frame_wrap_layout.setContentsMargins(0, 0, 0, 0)
        self.chest_info_frame = QFrame(self.chest_info_frame_wrap)
        self.chest_info_frame.setObjectName(u"chest_info_frame")
        self.chest_info_frame.setMinimumSize(QSize(200, 30))
        self.chest_info_frame.setMaximumSize(QSize(200, 16777215))
        self.chest_info_frame.setFrameShape(QFrame.StyledPanel)
        self.chest_info_frame.setFrameShadow(QFrame.Raised)
        self.chest_info_frame_layout = QHBoxLayout(self.chest_info_frame)
        self.chest_info_frame_layout.setSpacing(0)
        self.chest_info_frame_layout.setObjectName(u"chest_info_frame_layout")
        self.chest_info_frame_layout.setContentsMargins(0, 0, 0, 0)

        self.chest_info_frame_wrap_layout.addWidget(self.chest_info_frame, 0, 0, 1, 1)


        self.gridLayout.addWidget(self.chest_info_frame_wrap, 2, 0, 1, 1)

        self.summoner_icon_frame = QFrame(self.summoner_info_frame)
        self.summoner_icon_frame.setObjectName(u"summoner_icon_frame")
        self.summoner_icon_frame.setMinimumSize(QSize(110, 110))
        self.summoner_icon_frame.setMaximumSize(QSize(16777215, 110))
        self.summoner_icon_frame.setFrameShape(QFrame.StyledPanel)
        self.summoner_icon_frame.setFrameShadow(QFrame.Raised)
        self.summoner_icon_frame_layout = QVBoxLayout(self.summoner_icon_frame)
        self.summoner_icon_frame_layout.setObjectName(u"summoner_icon_frame_layout")
        self.summoner_icon_frame_layout.setContentsMargins(0, 0, 0, 0)

        self.gridLayout.addWidget(self.summoner_icon_frame, 0, 0, 1, 1)

        self.summoner_name_frame_wrap = QFrame(self.summoner_info_frame)
        self.summoner_name_frame_wrap.setObjectName(u"summoner_name_frame_wrap")
        self.summoner_name_frame_wrap.setMinimumSize(QSize(200, 50))
        self.summoner_name_frame_wrap.setMaximumSize(QSize(16777215, 50))
        font2 = QFont()
        font2.setFamily(u"Gill Sans MT")
        font2.setPointSize(16)
        self.summoner_name_frame_wrap.setFont(font2)
        self.summoner_name_frame_wrap.setFrameShape(QFrame.StyledPanel)
        self.summoner_name_frame_wrap.setFrameShadow(QFrame.Raised)
        self.summoner_name_frame_wrap_layout = QGridLayout(self.summoner_name_frame_wrap)
        self.summoner_name_frame_wrap_layout.setObjectName(u"summoner_name_frame_wrap_layout")
        self.summoner_name_frame_wrap_layout.setContentsMargins(0, 0, 0, 0)
        self.summoner_name_frame = QFrame(self.summoner_name_frame_wrap)
        self.summoner_name_frame.setObjectName(u"summoner_name_frame")
        self.summoner_name_frame.setMinimumSize(QSize(300, 0))
        self.summoner_name_frame.setMaximumSize(QSize(300, 16777215))
        self.summoner_name_frame.setFrameShape(QFrame.StyledPanel)
        self.summoner_name_frame.setFrameShadow(QFrame.Raised)
        self.summoner_name_frame_layout = QVBoxLayout(self.summoner_name_frame)
        self.summoner_name_frame_layout.setSpacing(0)
        self.summoner_name_frame_layout.setObjectName(u"summoner_name_frame_layout")
        self.summoner_name_frame_layout.setContentsMargins(0, 0, 0, 0)

        self.summoner_name_frame_wrap_layout.addWidget(self.summoner_name_frame, 0, 0, 1, 1)


        self.gridLayout.addWidget(self.summoner_name_frame_wrap, 1, 0, 1, 1)


        self.contents_main_page_layout.addWidget(self.summoner_info_frame)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.contents_main_page_layout.addItem(self.verticalSpacer)

        self.scroll_area_main_page.setWidget(self.contents_main_page)

        self.verticalLayout_3.addWidget(self.scroll_area_main_page)

        self.pages.addWidget(self.main_page)

        self.main_pages_layout.addWidget(self.pages)


        self.retranslateUi(MainPages)

        self.pages.setCurrentIndex(2)


        QMetaObject.connectSlotsByName(MainPages)
    # setupUi

    def retranslateUi(self, MainPages):
        MainPages.setWindowTitle(QCoreApplication.translate("MainPages", u"Form", None))
    # retranslateUi

