# ///////////////////////////////////////////////////////////////
#
# BY: WANDERSON M.PIMENTA
# PROJECT MADE WITH: Qt Designer and PySide6
# V: 1.0.0
#
# This project can be used freely for all uses, as long as they maintain the
# respective credits only in the Python scripts, any information in the visual
# interface (GUI) can be modified without any implication.
#
# There are limitations on Qt licenses if you want to use your products
# commercially, I recommend reading them on the official website:
# https://doc.qt.io/qtforpython/licenses.html
#
# ///////////////////////////////////////////////////////////////

# IMPORT PACKAGES AND MODULES
# ///////////////////////////////////////////////////////////////
from socket import create_server
from time import sleep

from requests import delete
from functions_api import get_chest_info, get_encryptedSummonerId, get_summoner_icon_link, translate_id_to_champion_name
from functions_other import check_if_LeagueClient_is_active, find_LoL_path, get_port_and_password
from functions_qt import circleImage
from functions_request import check_if_aram_lobby, get_champions_owned, get_how_many_chests_available, get_pickable_champions_aram, get_summoner_icon, get_summoner_icon_id, get_summoner_name
from ....widgets.py_label_with_bg.py_label_bg import PyLabelBg
from gui.widgets.py_table_widget.py_table_widget import PyTableWidget
from . functions_main_window import *
import sys
import os
import requests

# IMPORT QT CORE
# ///////////////////////////////////////////////////////////////
from qt_core import *

# IMPORT SETTINGS
# ///////////////////////////////////////////////////////////////
from gui.core.json_settings import Settings

# IMPORT THEME COLORS
# ///////////////////////////////////////////////////////////////
from gui.core.json_themes import Themes

# IMPORT PY ONE DARK WIDGETS
# ///////////////////////////////////////////////////////////////
from gui.widgets import *

# LOAD UI MAIN
# ///////////////////////////////////////////////////////////////
from . ui_main import *

# MAIN FUNCTIONS 
# ///////////////////////////////////////////////////////////////
from . functions_main_window import *

# MAIN FUNCTIONS 
# ///////////////////////////////////////////////////////////////
class WorkerSignals(QObject):
    '''
    Defines the signals available from a running worker thread.

    Supported signals are:

    finished
        No data

    error
        tuple (exctype, value, traceback.format_exc() )

    result
        object data returned from processing, anything

    progress
        int indicating % progress

    '''
    finished = Signal()
    error = Signal(tuple)
    result = Signal(object)
    progress = Signal(str)
    load_champion_table = Signal()
    load_aram_table = Signal()
    change_config = Signal(str)
    load_main_page = Signal()
    no_client_connection = Signal()


class Check_if_client_active_Worker(QObject):

    '''
    Worker thread
    '''
    def __init__(self, main_window):
        super(Check_if_client_active_Worker, self).__init__()
        # self.args = args
        # self.kwargs = kwarg
        self.signals = WorkerSignals()
        self.main_window = main_window

    @Slot()  # QtCore.Slot
    def run(self):
        while(1):
            sleep(3)
            # self.signals.progress.emit("0")
            if check_if_LeagueClient_is_active():
                try:
                    # CHECK IF CLIENT IS ACTIVE 
                    self.path = find_LoL_path()
                    self.port, self.password = get_port_and_password(self.path)
                    self.encrypted_summonerId = get_encryptedSummonerId('eun1', get_summoner_name(self.port, self.password))
                    self.chest_info = get_chest_info('eun1', self.encrypted_summonerId)
                    self.champions_owned = get_champions_owned(self.port, self.password)
                    self.summoner_name = get_summoner_name(self.port, self.password)

                    # CHECK IF CONFIG CHANGED
                    if self.path != self.main_window.config["lolPath"]:
                        self.main_window.config["lolPath"] = self.path
                        self.signals.change_config.emit("lolPath")
                    if self.port != self.main_window.config["port"] or self.password != self.main_window.config["password"]:
                        self.main_window.config["port"] = self.port
                        self.main_window.config["password"] = self.password
                        self.signals.change_config.emit("port and password")
                    if self.encrypted_summonerId != self.main_window.config["encryptedSummonerId"]:
                        self.main_window.config["encryptedSummonerId"] = self.encrypted_summonerId
                        self.signals.change_config.emit("encryptedSummonerId")
                    if self.champions_owned != self.main_window.config["playerInfo"]["championsOwned"]:
                        self.main_window.config["playerInfo"]["championsOwned"] = self.champions_owned
                        self.signals.change_config.emit("playerInfo -> championsOwned")
                    if self.summoner_name != self.main_window.config["playerInfo"]["summonerName"]:
                        self.main_window.config["playerInfo"]["summonerName"] = self.summoner_name
                        self.signals.change_config.emit("playerInfo -> summonerName")
                        # IF summonerName CHANGED LOAD IT
                        self.signals.load_main_page.emit()
                    if self.chest_info != self.main_window.config["playerInfo"]["chestInfo"]:
                        self.main_window.config["playerInfo"]["chestInfo"] = self.chest_info
                        self.signals.change_config.emit("playerInfo -> chestInfo")
                        # IF chestInfo CHANGED RELOAD TABLE
                        self.signals.load_champion_table.emit()
                        

                    # ACTIVE ARAM LOBBY
                    if check_if_aram_lobby(self.port, self.password):
                        # self.signals.progress.emit("5")
                        get_pickable_champions_aram(self.port, self.password)
                        self.signals.load_aram_table.emit()

                    self.main_window.config["isLoading"] = False
                    

                except:
                    if not self.main_window.config["isLoading"]:
                        self.main_window.config["isLoading"] = True
                        self.signals.no_client_connection.emit()
                    continue
        self.signals.finished.emit()

    def stop(self):
        self._isRunning = False



# PY WINDOW
# ///////////////////////////////////////////////////////////////
class SetupMainWindow:
    def __init__(self):
        super().__init__()
        # SETUP MAIN WINDOw
        # Load widgets from "gui\uis\main_window\ui_main.py"
        # ///////////////////////////////////////////////////////////////
        self.ui = UI_MainWindow()
        self.ui.setup_ui(self)

    # ADD LEFT MENUS
    # ///////////////////////////////////////////////////////////////
    add_left_menus = [
        {
            "btn_icon" : "icon_home.svg",
            "btn_id" : "btn_main",
            "btn_text" : "Main Lobby",
            "btn_tooltip" : "Main Lobby",
            "show_top" : True,
            "is_active" : True
        },
        {
            "btn_icon" : "icon_heart.svg",
            "btn_id" : "btn_champions",
            "btn_text" : "All Champions",
            "btn_tooltip" : "All Champions",
            "show_top" : True,
            "is_active" : False
        },
        {
            "btn_icon" : "icon_widgets.svg",
            "btn_id" : "btn_aram",
            "btn_text" : "ARAM Page",
            "btn_tooltip" : "ARAM Page",
            "show_top" : True,
            "is_active" : False
        },
        # # {
        # #     "btn_icon" : "icon_add_user.svg",
        # #     "btn_id" : "btn_add_user",
        # #     "btn_text" : "Add Users",
        # #     "btn_tooltip" : "Add users",
        # #     "show_top" : True,
        # #     "is_active" : False
        # # },
        # # {
        # #     "btn_icon" : "icon_file.svg",
        # #     "btn_id" : "btn_new_file",
        # #     "btn_text" : "New File",
        # #     "btn_tooltip" : "Create new file",
        # #     "show_top" : True,
        # #     "is_active" : False
        # # },
        # # {
        # #     "btn_icon" : "icon_folder_open.svg",
        # #     "btn_id" : "btn_open_file",
        # #     "btn_text" : "Open File",
        # #     "btn_tooltip" : "Open file",
        # #     "show_top" : True,
        # #     "is_active" : False
        # # },
        # # {
        # #     "btn_icon" : "icon_save.svg",
        # #     "btn_id" : "btn_save",
        # #     "btn_text" : "Save File",
        # #     "btn_tooltip" : "Save file",
        # #     "show_top" : True,
        # #     "is_active" : False
        # # },
        # # {
        # #     "btn_icon" : "icon_info.svg",
        # #     "btn_id" : "btn_info",
        # #     "btn_text" : "Information",
        # #     "btn_tooltip" : "Open informations",
        # #     "show_top" : False,
        # #     "is_active" : False
        # # },
        # # {
        # #     "btn_icon" : "icon_settings.svg",
        # #     "btn_id" : "btn_settings",
        # #     "btn_text" : "Settings",
        # #     "btn_tooltip" : "Open settings",
        # #     "show_top" : False,
        # #     "is_active" : False
        # # }
    ]

     # ADD TITLE BAR MENUS
    # ///////////////////////////////////////////////////////////////
    add_title_bar_menus = [
        {
            "btn_icon" : "icon_search.svg",
            "btn_id" : "btn_search",
            "btn_tooltip" : "Search",
            "is_active" : False
        },
        {
            "btn_icon" : "icon_settings.svg",
            "btn_id" : "btn_top_settings",
            "btn_tooltip" : "Top settings",
            "is_active" : False
        }
    ]

    # SETUP CUSTOM BTNs OF CUSTOM WIDGETS
    # Get sender() function when btn is clicked
    # ///////////////////////////////////////////////////////////////
    def setup_btns(self):
        if self.ui.title_bar.sender() != None:
            return self.ui.title_bar.sender()
        elif self.ui.left_menu.sender() != None:
            return self.ui.left_menu.sender()
        elif self.ui.left_column.sender() != None:
            return self.ui.left_column.sender()

    # SETUP MAIN WINDOW WITH CUSTOM PARAMETERS
    # ///////////////////////////////////////////////////////////////
    def setup_gui(self):
        # APP TITLE
        # ///////////////////////////////////////////////////////////////
        self.setWindowTitle(self.settings["app_name"])
        
        # REMOVE TITLE BAR
        # ///////////////////////////////////////////////////////////////
        if self.settings["custom_title_bar"]:
            self.setWindowFlag(Qt.FramelessWindowHint)
            self.setAttribute(Qt.WA_TranslucentBackground)

        # ADD GRIPS
        # ///////////////////////////////////////////////////////////////
        if self.settings["custom_title_bar"]:
            self.left_grip = PyGrips(self, "left", self.hide_grips)
            self.right_grip = PyGrips(self, "right", self.hide_grips)
            self.top_grip = PyGrips(self, "top", self.hide_grips)
            self.bottom_grip = PyGrips(self, "bottom", self.hide_grips)
            self.top_left_grip = PyGrips(self, "top_left", self.hide_grips)
            self.top_right_grip = PyGrips(self, "top_right", self.hide_grips)
            self.bottom_left_grip = PyGrips(self, "bottom_left", self.hide_grips)
            self.bottom_right_grip = PyGrips(self, "bottom_right", self.hide_grips)

        # LEFT MENUS / GET SIGNALS WHEN LEFT MENU BTN IS CLICKED / RELEASED
        # ///////////////////////////////////////////////////////////////
        # ADD MENUS
        self.ui.left_menu.add_menus(SetupMainWindow.add_left_menus)

        # SET SIGNALS
        self.ui.left_menu.clicked.connect(self.btn_clicked)
        self.ui.left_menu.released.connect(self.btn_released)

        # TITLE BAR / ADD EXTRA BUTTONS
        # ///////////////////////////////////////////////////////////////
        # ADD MENUS
        self.ui.title_bar.add_menus(SetupMainWindow.add_title_bar_menus)

        # SET SIGNALS
        self.ui.title_bar.clicked.connect(self.btn_clicked)
        self.ui.title_bar.released.connect(self.btn_released)

        # ADD Title
        if self.settings["custom_title_bar"]:
            self.ui.title_bar.set_title(self.settings["app_name"])
        else:
            self.ui.title_bar.set_title("Welcome to PyOneDark")

        # LEFT COLUMN SET SIGNALS
        # ///////////////////////////////////////////////////////////////
        self.ui.left_column.clicked.connect(self.btn_clicked)
        self.ui.left_column.released.connect(self.btn_released)

        # SET INITIAL PAGE / SET LEFT AND RIGHT COLUMN MENUS
        # ///////////////////////////////////////////////////////////////
        MainFunctions.set_page(self, self.ui.load_pages.main_page)
        MainFunctions.set_left_column_menu(
            self,
            menu = self.ui.left_column.menus.menu_1,
            title = "Settings Left Column",
            icon_path = Functions.set_svg_icon("icon_settings.svg")
        )
        MainFunctions.set_right_column_menu(self, self.ui.right_column.menu_1)

        # ///////////////////////////////////////////////////////////////
        # EXAMPLE CUSTOM WIDGETS
        # Here are added the custom widgets to pages and columns that
        # were created using Qt Designer.
        # This is just an example and should be deleted when creating
        # your application.
        #
        # OBJECTS FOR LOAD PAGES, LEFT AND RIGHT COLUMNS
        # You can access objects inside Qt Designer projects using
        # the objects below:
        #
        # <OBJECTS>
        # LEFT COLUMN: self.ui.left_column.menus
        # RIGHT COLUMN: self.ui.right_column
        # LOAD PAGES: self.ui.load_pages
        # </OBJECTS>
        # ///////////////////////////////////////////////////////////////

        # LOAD SETTINGS
        # ///////////////////////////////////////////////////////////////
        settings = Settings()
        self.settings = settings.items

        # LOAD THEME COLOR
        # ///////////////////////////////////////////////////////////////
        themes = Themes()
        self.themes = themes.items

        # # # LEFT COLUMN
        # # # ///////////////////////////////////////////////////////////////

        # # # BTN 1
        # # self.left_btn_1 = PyPushButton(
        # #     text="Btn 1",
        # #     radius=8,
        # #     color=self.themes["app_color"]["text_foreground"],
        # #     bg_color=self.themes["app_color"]["dark_one"],
        # #     bg_color_hover=self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed=self.themes["app_color"]["dark_four"]
        # # )
        # # self.left_btn_1.setMaximumHeight(40)
        # # self.ui.left_column.menus.btn_1_layout.addWidget(self.left_btn_1)

        # # # BTN 2
        # # self.left_btn_2 = PyPushButton(
        # #     text="Btn With Icon",
        # #     radius=8,
        # #     color=self.themes["app_color"]["text_foreground"],
        # #     bg_color=self.themes["app_color"]["dark_one"],
        # #     bg_color_hover=self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed=self.themes["app_color"]["dark_four"]
        # # )
        # # self.icon = QIcon(Functions.set_svg_icon("icon_settings.svg"))
        # # self.left_btn_2.setIcon(self.icon)
        # # self.left_btn_2.setMaximumHeight(40)
        # # self.ui.left_column.menus.btn_2_layout.addWidget(self.left_btn_2)

        # # # BTN 3 - Default QPushButton
        # # self.left_btn_3 = QPushButton("Default QPushButton")
        # # self.left_btn_3.setMaximumHeight(40)
        # # self.ui.left_column.menus.btn_3_layout.addWidget(self.left_btn_3)

        # CONFIG
        # ///////////////////////////////////////////////////////////////

        self.config = {
            "lolPath": None,
            "port": None,
            "password": None,
            "region": None,
            "encryptedSummonerId": None,
            "isLoading": False,
            "playerInfo": {
                "summonerName": None,
                "chestInfo": None,             # [{'championName': 'Jinx', 'championId': 222, 'chestGranted': True}, {...}]
                "championsOwned": None,        # [{'name': 'Annie', 'id': 1}, {...}]
            }
        }

        def config_changed(what_changed):
            print("Config changed: {}".format(what_changed))

        # PAGES
        # ///////////////////////////////////////////////////////////////

        # MAIN PAGE
        # ///////////////////////////////////////////////////////////////
        def clear_pages():
            for i in reversed(range(self.ui.load_pages.summoner_name_frame_layout.count())): 
                self.ui.load_pages.summoner_name_frame_layout.itemAt(i).widget().deleteLater()

            for i in reversed(range(self.ui.load_pages.summoner_icon_frame_layout.count())): 
                self.ui.load_pages.summoner_icon_frame_layout.itemAt(i).widget().deleteLater()

            for i in reversed(range(self.ui.load_pages.chest_info_frame_layout.count())): 
                self.ui.load_pages.chest_info_frame_layout.itemAt(i).widget().deleteLater()
            try:
                while (self.aram_table_widget.rowCount() > 0):
                    self.aram_table_widget.removeRow(0)

                while (self.champions_table_widget.rowCount() > 0):
                    self.champions_table_widget.removeRow(0)
            except:
                pass
    

        def loading_page():
            clear_pages()
            # loading_label = QLabel()
            loading_label = PyLabelBg(
                # bg_two = self.themes["app_color"]["dark_two"],
                text = "Trying to connect to client...",
                font_family = self.settings["font"]["family"],
                text_size = 18,
                text_description_color = self.themes["app_color"]["text_description"]
            )
            # self.loading_gif = QMovie('loading8.gif')
            # loading_label.setMovie(self.loading_gif)
            # self.loading_gif.setScaledSize(QSize().scaled(50, 50, Qt.KeepAspectRatio))
            # loading_label.setAlignment(Qt.AlignHCenter | Qt.AlignBottom)
            self.ui.load_pages.summoner_icon_frame_layout.addWidget(loading_label)
            # self.loading_gif.start()
        
        loading_page()

        def main_page():
            # self.loading_gif.stop()
            for i in reversed(range(self.ui.load_pages.summoner_name_frame_layout.count())): 
                self.ui.load_pages.summoner_name_frame_layout.itemAt(i).widget().deleteLater()

            for i in reversed(range(self.ui.load_pages.summoner_icon_frame_layout.count())): 
                self.ui.load_pages.summoner_icon_frame_layout.itemAt(i).widget().deleteLater()

            for i in reversed(range(self.ui.load_pages.chest_info_frame_layout.count())): 
                self.ui.load_pages.chest_info_frame_layout.itemAt(i).widget().deleteLater()


            summoner_name_label = PyLabelBg(
                bg_two = self.themes["app_color"]["dark_two"],
                text = self.config["playerInfo"]["summonerName"],
                font_family = "Baskerville Old Face",
                text_size = 23,
                text_description_color = self.themes["app_color"]["text_description"]
            )
            self.ui.load_pages.summoner_name_frame_layout.addWidget(summoner_name_label)

            summoner_icon_response = get_summoner_icon(self.config['port'], self.config['password'], get_summoner_icon_id(self.config['port'], self.config['password']))
            data = summoner_icon_response.content
            summoner_icon = circleImage(data, size=100)
            summoner_icon_label = QLabel()
            summoner_icon_label.setAlignment(Qt.AlignCenter)
            summoner_icon_label.setPixmap(summoner_icon)

            self.ui.load_pages.summoner_icon_frame_layout.addWidget(summoner_icon_label)
            
            # chest_availibility_info_icon_label = QLabel()
            # chest_availibility_info_icon_label.setAlignment(Qt.AlignCenter)
            # chest_pixmap = QPixmap('chest_icon.png')
            # chest_pixmap = chest_pixmap.scaled(23, 23)
            # chest_availibility_info_icon_label.setPixmap(chest_pixmap)

            chest_availibility_info = get_how_many_chests_available(self.config['port'], self.config['password'])
            # # chest_availibility_info_label = QLabel("{}/{}".format(chest_availibility_info['earnableChests'], chest_availibility_info['maximumChests']))
            # # chest_availibility_info_label.setAlignment(Qt.AlignCenter)

            # # self.ui.load_pages.chest_info_frame_layout.addWidget(chest_availibility_info_icon_label)
            # # self.ui.load_pages.chest_info_frame_layout.addWidget(chest_availibility_info_label)

            # chest_availibility_label_temp = QLabel("{} out of {} chests available!".format(chest_availibility_info['earnableChests'], chest_availibility_info['maximumChests']))
            # chest_availibility_label_temp.setStyleSheet('background-color: {}'.format(self.themes["app_color"]["dark_two"]))
            # self.ui.load_pages.chest_info_wrap_layout.addWidget(chest_availibility_label_temp)
            num_to_word = {1: 'One', 2: 'Two', 3: 'Three', 4: 'Four'}
            chest_availibility_label = PyLabelBg(
                bg_two = self.themes["app_color"]["dark_two"],
                text = "{} chests available!".format(num_to_word[chest_availibility_info['earnableChests']]),
                font_family = self.settings["font"]["family"],
                text_size = self.settings["font"]["text_size"],
                text_description_color = "#9B8E59"
            )

            #  ADD TO LAYOUT
            # self.ui.load_pages.chest_info_frame.deleteLater()
            self.ui.load_pages.chest_info_frame_layout.addWidget(chest_availibility_label)









        # CHAMPION PAGE
        # ///////////////////////////////////////////////////////////////

        self.line_edit_search_champion = PyLineEdit(
            text = "",
            place_holder_text = "Find Champion",
            radius = 8,
            border_size = 2,
            color = self.themes["app_color"]["text_foreground"],
            selection_color = self.themes["app_color"]["white"],
            bg_color = self.themes["app_color"]["dark_one"],
            bg_color_active = self.themes["app_color"]["dark_three"],
            context_color = self.themes["app_color"]["context_color"]
        )

        self.line_edit_search_champion.setMinimumHeight(40)
        self.ui.load_pages.searchbar_frame_layout.addWidget(self.line_edit_search_champion)
        
        # FILTER BUTTONS
        self.all_filter_button = PyPushButton(
            text="Show All",
            radius=8,
            color=self.themes["app_color"]["text_foreground"],
            bg_color=self.themes["app_color"]["dark_one"],
            bg_color_hover=self.themes["app_color"]["dark_three"],
            bg_color_pressed=self.themes["app_color"]["dark_four"]
        )
        self.all_filter_button.setMinimumHeight(30)
        self.ui.load_pages.filter_frame_layout.addWidget(self.all_filter_button)
        self.all_filter_button.clicked.connect(lambda: filter_chapions_in_table(""))
        
        self.granted_filter_button = PyPushButton(
            text="Show Granted Only",
            radius=8,
            color=self.themes["app_color"]["text_foreground"],
            bg_color=self.themes["app_color"]["dark_one"],
            bg_color_hover=self.themes["app_color"]["dark_three"],
            bg_color_pressed=self.themes["app_color"]["dark_four"]
        )
        self.granted_filter_button.setMinimumHeight(30)
        self.ui.load_pages.filter_frame_layout.addWidget(self.granted_filter_button)
        self.granted_filter_button.clicked.connect(lambda: filter_chapions_in_table("granted"))

        self.available_filter_button = PyPushButton(
            text="Show Available Only",
            radius=8,
            color=self.themes["app_color"]["text_foreground"],
            bg_color=self.themes["app_color"]["dark_one"],
            bg_color_hover=self.themes["app_color"]["dark_three"],
            bg_color_pressed=self.themes["app_color"]["dark_four"]
        )
        self.available_filter_button.setMinimumHeight(30)
        self.ui.load_pages.filter_frame_layout.addWidget(self.available_filter_button)
        self.available_filter_button.clicked.connect(lambda: filter_chapions_in_table("available"))

        def filter_chapions_in_table(filter):
            for row in range(self.champions_table_widget.rowCount()):
                cell_2 = self.champions_table_widget.item(row, 1)
                # if the search is *not* in the item's text *do not hide* the row
                self.champions_table_widget.setRowHidden(row, filter not in cell_2.text().lower())

        def search_champion_in_table():
            name = self.line_edit_search_champion.text().lower()
            for row in range(self.champions_table_widget.rowCount()):
                cell_1 = self.champions_table_widget.item(row, 0) 
                # cell_2 = self.champions_table_widget.item(row, 1)
                # if the search is *not* in the item's text *do not hide* the row
                self.champions_table_widget.setRowHidden(row, name not in cell_1.text().lower()) # and name not in cell_2.text().lower())
        
        self.line_edit_search_champion.textChanged.connect(search_champion_in_table)

        # TABLE WIDGETS
        self.champions_table_widget = PyTableWidget(
            radius = 8,
            color = self.themes["app_color"]["text_foreground"],
            selection_color = self.themes["app_color"]["context_color"],
            bg_color = self.themes["app_color"]["bg_two"],
            header_horizontal_color = self.themes["app_color"]["dark_two"],
            header_vertical_color = self.themes["app_color"]["bg_three"],
            bottom_line_color = self.themes["app_color"]["bg_three"],
            grid_line_color = self.themes["app_color"]["bg_one"],
            scroll_bar_bg_color = self.themes["app_color"]["bg_one"],
            scroll_bar_btn_color = self.themes["app_color"]["dark_four"],
            context_color = self.themes["app_color"]["context_color"]
        )
        self.champions_table_widget.setColumnCount(2)
        self.champions_table_widget.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.champions_table_widget.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.champions_table_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.champions_table_widget.setSelectionBehavior(QAbstractItemView.SelectRows)

        # Columns / Header
        self.column_1 = QTableWidgetItem()
        self.column_1.setTextAlignment(Qt.AlignCenter)
        self.column_1.setText("Champion")

        self.column_2 = QTableWidgetItem()
        self.column_2.setTextAlignment(Qt.AlignCenter)
        self.column_2.setText("Chest Availability")


        # Set column
        self.champions_table_widget.setHorizontalHeaderItem(0, self.column_1)
        self.champions_table_widget.setHorizontalHeaderItem(1, self.column_2)

        self.ui.load_pages.champion_table_frame_layout.addWidget(self.champions_table_widget)

        # GET INFO FOR TABLE

        def get_info_for_table():
            print('Client up, loading contents!')
            while (self.champions_table_widget.rowCount() > 0):
                self.champions_table_widget.removeRow(0)

            self.champions_owned_ids = []
            for row in self.config["playerInfo"]["championsOwned"]:
                self.champions_owned_ids.append(row['id'])

            create_table_records()

        # ADD CHAMPION -> CHEST INFO TO TABLE
        
        def create_table_records():
            for row in self.config["playerInfo"]["chestInfo"]:
                if row['chestGranted'] == True and int(row['championId']) in self.champions_owned_ids:
                    self.champions_owned_ids.remove(int(row['championId']))
                    row_number = self.champions_table_widget.rowCount()
                    self.champions_table_widget.insertRow(row_number)
                    self.champions_table_widget.setItem(row_number, 0, QTableWidgetItem(str(row['championName'])))
                    self.champions_table_widget.setItem(row_number, 1, QTableWidgetItem('Granted'))
                    self.champions_table_widget.item(row_number, 0).setFlags(Qt.ItemIsEnabled)
                    self.champions_table_widget.item(row_number, 1).setFlags(Qt.ItemIsEnabled)
                elif row['chestGranted'] == False and int(row['championId']) in self.champions_owned_ids:
                    self.champions_owned_ids.remove(int(row['championId']))
                    row_number = self.champions_table_widget.rowCount()
                    self.champions_table_widget.insertRow(row_number)
                    self.champions_table_widget.setItem(row_number, 0, QTableWidgetItem(str(row['championName'])))
                    self.champions_table_widget.setItem(row_number, 1, QTableWidgetItem('Available'))
                    self.champions_table_widget.item(row_number, 0).setFlags(Qt.ItemIsEnabled)
                    self.champions_table_widget.item(row_number, 1).setFlags(Qt.ItemIsEnabled)

            for element in self.champions_owned_ids:
                    champion = QTableWidgetItem(next((item for item in self.config["playerInfo"]["championsOwned"] if item["id"] == element), None)['name'])
                    row_number = self.champions_table_widget.rowCount()
                    self.champions_table_widget.insertRow(row_number)
                    self.champions_table_widget.setItem(row_number, 0, champion)
                    self.champions_table_widget.setItem(row_number, 1, QTableWidgetItem('Available'))
                    self.champions_table_widget.item(row_number, 0).setFlags(Qt.ItemIsEnabled)
                    self.champions_table_widget.item(row_number, 1).setFlags(Qt.ItemIsEnabled)

        # ARAM PAGE
        # ///////////////////////////////////////////////////////////////

        # TABLE WIDGETS
        self.aram_table_widget = PyTableWidget(
            radius = 8,
            color = self.themes["app_color"]["text_foreground"],
            selection_color = self.themes["app_color"]["context_color"],
            bg_color = self.themes["app_color"]["bg_two"],
            header_horizontal_color = self.themes["app_color"]["dark_two"],
            header_vertical_color = self.themes["app_color"]["bg_three"],
            bottom_line_color = self.themes["app_color"]["bg_three"],
            grid_line_color = self.themes["app_color"]["bg_one"],
            scroll_bar_bg_color = self.themes["app_color"]["bg_one"],
            scroll_bar_btn_color = self.themes["app_color"]["dark_four"],
            context_color = self.themes["app_color"]["context_color"]
        )
        self.aram_table_widget.setColumnCount(2)
        self.aram_table_widget.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.aram_table_widget.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.aram_table_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.aram_table_widget.setSelectionBehavior(QAbstractItemView.SelectRows)

        # Columns / Header
        self.column_1 = QTableWidgetItem()
        self.column_1.setTextAlignment(Qt.AlignCenter)
        self.column_1.setText("Champion")

        self.column_2 = QTableWidgetItem()
        self.column_2.setTextAlignment(Qt.AlignCenter)
        self.column_2.setText("Chest Availability")


        # Set column
        self.aram_table_widget.setHorizontalHeaderItem(0, self.column_1)
        self.aram_table_widget.setHorizontalHeaderItem(1, self.column_2)

        self.ui.load_pages.aram_table_frame_layout.addWidget(self.aram_table_widget)


        def create_table_records_aram():
            while (self.aram_table_widget.rowCount() > 0):
                self.aram_table_widget.removeRow(0)
            champion_aram_ids = get_pickable_champions_aram(self.config["port"], self.config["password"])
            
            champions_owned_ids_aram = []
            for row in self.config["playerInfo"]["championsOwned"]:
                champions_owned_ids_aram.append(row['id'])
            champion_names = translate_id_to_champion_name (champion_aram_ids)

            for i in range (len(champion_aram_ids)):
                if int(champion_aram_ids[i]) in champions_owned_ids_aram:
                    champion = QTableWidgetItem(champion_names[i])
                    champion.setFlags(Qt.ItemIsEnabled)
                    for j in range (len(self.config["playerInfo"]["chestInfo"])):
                        if self.config["playerInfo"]["chestInfo"][j]['championId'] == champion_aram_ids[i]:
                            chest = self.config["playerInfo"]["chestInfo"][j]['chestGranted']
                            break
                        else:
                            chest = False
                    if chest == False:
                        self.aram_table_widget.insertRow(i)
                        chest = QTableWidgetItem('Available')
                        chest.setFlags(Qt.ItemIsEnabled)
                        self.aram_table_widget.setItem(i, 1, chest)
                        # self.aram_table_widget.item(i, 1).setBackground(QColor(152, 251, 152))
                        self.aram_table_widget.setItem(i, 0, champion)
                    else:
                        self.aram_table_widget.insertRow(i)
                        chest = QTableWidgetItem('Granted')
                        chest.setFlags(Qt.ItemIsEnabled)
                        self.aram_table_widget.setItem(i, 1, chest)
                        # self.aram_table_widget.item(i, 1).setBackground(QColor(199, 81, 80))
                        self.aram_table_widget.setItem(i, 0, champion)
                else:
                    self.aram_table_widget.insertRow(i)
                    champion = QTableWidgetItem(champion_names[i])
                    chest = QTableWidgetItem('Not Owned')
                    champion.setFlags(Qt.ItemIsEnabled)
                    chest.setFlags(Qt.ItemIsEnabled)
                    self.aram_table_widget.setItem(i, 1, chest)
                    # self.aram_table_widget.item(i, 1).setBackground(QColor(220,220,220))
                    self.aram_table_widget.setItem(i, 0, champion)

        def print_progress(progress):
            print(progress)
            
        # THREADING
        # ///////////////////////////////////////////////////////////////

        self.chest_info = False
        champion_aram_ids = False
        self.thread = QThread()
        self.worker = Check_if_client_active_Worker(self)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.signals.progress.connect(print_progress)
        self.worker.signals.load_champion_table.connect(get_info_for_table)
        self.worker.signals.load_aram_table.connect(create_table_records_aram)
        self.worker.signals.change_config.connect(config_changed)
        self.worker.signals.load_main_page.connect(main_page)
        self.worker.signals.no_client_connection.connect(loading_page)
        self.worker.signals.finished.connect(self.thread.quit)
        self.worker.signals.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()



        # # # PAGE 1 - ADD LOGO TO MAIN PAGE
        # # self.logo_svg = QSvgWidget(Functions.set_svg_image("logo_home.svg"))
        # # self.ui.load_pages.logo_layout.addWidget(self.logo_svg, Qt.AlignCenter, Qt.AlignCenter)

        # # # PAGE 2
        # # # CIRCULAR PROGRESS 1
        # # self.circular_progress_1 = PyCircularProgress(
        # #     value = 80,
        # #     progress_color = self.themes["app_color"]["context_color"],
        # #     text_color = self.themes["app_color"]["text_title"],
        # #     font_size = 14,
        # #     bg_color = self.themes["app_color"]["dark_four"]
        # # )
        # # self.circular_progress_1.setFixedSize(200,200)

        # # # CIRCULAR PROGRESS 2
        # # self.circular_progress_2 = PyCircularProgress(
        # #     value = 45,
        # #     progress_width = 4,
        # #     progress_color = self.themes["app_color"]["context_color"],
        # #     text_color = self.themes["app_color"]["context_color"],
        # #     font_size = 14,
        # #     bg_color = self.themes["app_color"]["bg_three"]
        # # )
        # # self.circular_progress_2.setFixedSize(160,160)

        # # # CIRCULAR PROGRESS 3
        # # self.circular_progress_3 = PyCircularProgress(
        # #     value = 75,
        # #     progress_width = 2,
        # #     progress_color = self.themes["app_color"]["pink"],
        # #     text_color = self.themes["app_color"]["white"],
        # #     font_size = 14,
        # #     bg_color = self.themes["app_color"]["bg_three"]
        # # )
        # # self.circular_progress_3.setFixedSize(140,140)

        # # # PY SLIDER 1
        # # self.vertical_slider_1 = PySlider(
        # #     margin=8,
        # #     bg_size=10,
        # #     bg_radius=5,
        # #     handle_margin=-3,
        # #     handle_size=16,
        # #     handle_radius=8,
        # #     bg_color = self.themes["app_color"]["dark_three"],
        # #     bg_color_hover = self.themes["app_color"]["dark_four"],
        # #     handle_color = self.themes["app_color"]["context_color"],
        # #     handle_color_hover = self.themes["app_color"]["context_hover"],
        # #     handle_color_pressed = self.themes["app_color"]["context_pressed"]
        # # )
        # # self.vertical_slider_1.setMinimumHeight(100)

        # # # PY SLIDER 2
        # # self.vertical_slider_2 = PySlider(
        # #     bg_color = self.themes["app_color"]["dark_three"],
        # #     bg_color_hover = self.themes["app_color"]["dark_three"],
        # #     handle_color = self.themes["app_color"]["context_color"],
        # #     handle_color_hover = self.themes["app_color"]["context_hover"],
        # #     handle_color_pressed = self.themes["app_color"]["context_pressed"]
        # # )
        # # self.vertical_slider_2.setMinimumHeight(100)

        # # # PY SLIDER 3
        # # self.vertical_slider_3 = PySlider(
        # #     margin=8,
        # #     bg_size=10,
        # #     bg_radius=5,
        # #     handle_margin=-3,
        # #     handle_size=16,
        # #     handle_radius=8,
        # #     bg_color = self.themes["app_color"]["dark_three"],
        # #     bg_color_hover = self.themes["app_color"]["dark_four"],
        # #     handle_color = self.themes["app_color"]["context_color"],
        # #     handle_color_hover = self.themes["app_color"]["context_hover"],
        # #     handle_color_pressed = self.themes["app_color"]["context_pressed"]
        # # )
        # # self.vertical_slider_3.setOrientation(Qt.Horizontal)
        # # self.vertical_slider_3.setMaximumWidth(200)

        # # # PY SLIDER 4
        # # self.vertical_slider_4 = PySlider(
        # #     bg_color = self.themes["app_color"]["dark_three"],
        # #     bg_color_hover = self.themes["app_color"]["dark_three"],
        # #     handle_color = self.themes["app_color"]["context_color"],
        # #     handle_color_hover = self.themes["app_color"]["context_hover"],
        # #     handle_color_pressed = self.themes["app_color"]["context_pressed"]
        # # )
        # # self.vertical_slider_4.setOrientation(Qt.Horizontal)
        # # self.vertical_slider_4.setMaximumWidth(200)

        # # # ICON BUTTON 1
        # # self.icon_button_1 = PyIconButton(
        # #     icon_path = Functions.set_svg_icon("icon_heart.svg"),
        # #     parent = self,
        # #     app_parent = self.ui.central_widget,
        # #     tooltip_text = "Icon button - Heart",
        # #     width = 40,
        # #     height = 40,
        # #     radius = 20,
        # #     dark_one = self.themes["app_color"]["dark_one"],
        # #     icon_color = self.themes["app_color"]["icon_color"],
        # #     icon_color_hover = self.themes["app_color"]["icon_hover"],
        # #     icon_color_pressed = self.themes["app_color"]["icon_active"],
        # #     icon_color_active = self.themes["app_color"]["icon_active"],
        # #     bg_color = self.themes["app_color"]["dark_one"],
        # #     bg_color_hover = self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed = self.themes["app_color"]["pink"]
        # # )

        # # # ICON BUTTON 2
        # # self.icon_button_2 = PyIconButton(
        # #     icon_path = Functions.set_svg_icon("icon_add_user.svg"),
        # #     parent = self,
        # #     app_parent = self.ui.central_widget,
        # #     tooltip_text = "BTN with tooltip",
        # #     width = 40,
        # #     height = 40,
        # #     radius = 8,
        # #     dark_one = self.themes["app_color"]["dark_one"],
        # #     icon_color = self.themes["app_color"]["icon_color"],
        # #     icon_color_hover = self.themes["app_color"]["icon_hover"],
        # #     icon_color_pressed = self.themes["app_color"]["white"],
        # #     icon_color_active = self.themes["app_color"]["icon_active"],
        # #     bg_color = self.themes["app_color"]["dark_one"],
        # #     bg_color_hover = self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed = self.themes["app_color"]["green"],
        # # )

        # # # ICON BUTTON 3
        # # self.icon_button_3 = PyIconButton(
        # #     icon_path = Functions.set_svg_icon("icon_add_user.svg"),
        # #     parent = self,
        # #     app_parent = self.ui.central_widget,
        # #     tooltip_text = "BTN actived! (is_actived = True)",
        # #     width = 40,
        # #     height = 40,
        # #     radius = 8,
        # #     dark_one = self.themes["app_color"]["dark_one"],
        # #     icon_color = self.themes["app_color"]["icon_color"],
        # #     icon_color_hover = self.themes["app_color"]["icon_hover"],
        # #     icon_color_pressed = self.themes["app_color"]["white"],
        # #     icon_color_active = self.themes["app_color"]["icon_active"],
        # #     bg_color = self.themes["app_color"]["dark_one"],
        # #     bg_color_hover = self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed = self.themes["app_color"]["context_color"],
        # #     is_active = True
        # # )

        # # # PUSH BUTTON 1
        # # self.push_button_1 = PyPushButton(
        # #     text = "Button Without Icon",
        # #     radius  =8,
        # #     color = self.themes["app_color"]["text_foreground"],
        # #     bg_color = self.themes["app_color"]["dark_one"],
        # #     bg_color_hover = self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed = self.themes["app_color"]["dark_four"]
        # # )
        # # self.push_button_1.setMinimumHeight(40)

        # # # PUSH BUTTON 2
        # # self.push_button_2 = PyPushButton(
        # #     text = "Button With Icon",
        # #     radius = 8,
        # #     color = self.themes["app_color"]["text_foreground"],
        # #     bg_color = self.themes["app_color"]["dark_one"],
        # #     bg_color_hover = self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed = self.themes["app_color"]["dark_four"]
        # # )
        # # self.icon_2 = QIcon(Functions.set_svg_icon("icon_settings.svg"))
        # # self.push_button_2.setMinimumHeight(40)
        # # self.push_button_2.setIcon(self.icon_2)

        # # # PY LINE EDIT
        # # self.line_edit = PyLineEdit(
        # #     text = "",
        # #     place_holder_text = "Place holder text",
        # #     radius = 8,
        # #     border_size = 2,
        # #     color = self.themes["app_color"]["text_foreground"],
        # #     selection_color = self.themes["app_color"]["white"],
        # #     bg_color = self.themes["app_color"]["dark_one"],
        # #     bg_color_active = self.themes["app_color"]["dark_three"],
        # #     context_color = self.themes["app_color"]["context_color"]
        # # )
        # # self.line_edit.setMinimumHeight(30)

        # # # TOGGLE BUTTON
        # # self.toggle_button = PyToggle(
        # #     width = 50,
        # #     bg_color = self.themes["app_color"]["dark_two"],
        # #     circle_color = self.themes["app_color"]["icon_color"],
        # #     active_color = self.themes["app_color"]["context_color"]
        # # )

        # # # TABLE WIDGETS
        # # self.champions_table_widget = PyTableWidget(
        # #     radius = 8,
        # #     color = self.themes["app_color"]["text_foreground"],
        # #     selection_color = self.themes["app_color"]["context_color"],
        # #     bg_color = self.themes["app_color"]["bg_two"],
        # #     header_horizontal_color = self.themes["app_color"]["dark_two"],
        # #     header_vertical_color = self.themes["app_color"]["bg_three"],
        # #     bottom_line_color = self.themes["app_color"]["bg_three"],
        # #     grid_line_color = self.themes["app_color"]["bg_one"],
        # #     scroll_bar_bg_color = self.themes["app_color"]["bg_one"],
        # #     scroll_bar_btn_color = self.themes["app_color"]["dark_four"],
        # #     context_color = self.themes["app_color"]["context_color"]
        # # )
        # # self.champions_table_widget.setColumnCount(3)
        # # self.champions_table_widget.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        # # self.champions_table_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        # # self.champions_table_widget.setSelectionBehavior(QAbstractItemView.SelectRows)

        # # # Columns / Header
        # # self.column_1 = QTableWidgetItem()
        # # self.column_1.setTextAlignment(Qt.AlignCenter)
        # # self.column_1.setText("NAME")

        # # self.column_2 = QTableWidgetItem()
        # # self.column_2.setTextAlignment(Qt.AlignCenter)
        # # self.column_2.setText("NICK")

        # # self.column_3 = QTableWidgetItem()
        # # self.column_3.setTextAlignment(Qt.AlignCenter)
        # # self.column_3.setText("PASS")

        # # # Set column
        # # self.champions_table_widget.setHorizontalHeaderItem(0, self.column_1)
        # # self.champions_table_widget.setHorizontalHeaderItem(1, self.column_2)
        # # self.champions_table_widget.setHorizontalHeaderItem(2, self.column_3)

        # # for x in range(10):
        # #     row_number = self.champions_table_widget.rowCount()
        # #     self.champions_table_widget.insertRow(row_number) # Insert row
        # #     self.champions_table_widget.setItem(row_number, 0, QTableWidgetItem(str("Wanderson"))) # Add name
        # #     self.champions_table_widget.setItem(row_number, 1, QTableWidgetItem(str("vfx_on_fire_" + str(x)))) # Add nick
        # #     self.pass_text = QTableWidgetItem()
        # #     self.pass_text.setTextAlignment(Qt.AlignCenter)
        # #     self.pass_text.setText("12345" + str(x))
        # #     self.champions_table_widget.setItem(row_number, 2, self.pass_text) # Add pass
        # #     self.champions_table_widget.setRowHeight(row_number, 22)

        # # # ADD WIDGETS
        # # self.ui.load_pages.row_1_layout.addWidget(self.circular_progress_1)
        # # self.ui.load_pages.row_1_layout.addWidget(self.circular_progress_2)
        # # self.ui.load_pages.row_1_layout.addWidget(self.circular_progress_3)
        # # self.ui.load_pages.row_2_layout.addWidget(self.vertical_slider_1)
        # # self.ui.load_pages.row_2_layout.addWidget(self.vertical_slider_2)
        # # self.ui.load_pages.row_2_layout.addWidget(self.vertical_slider_3)
        # # self.ui.load_pages.row_2_layout.addWidget(self.vertical_slider_4)
        # # self.ui.load_pages.row_3_layout.addWidget(self.icon_button_1)
        # # self.ui.load_pages.row_3_layout.addWidget(self.icon_button_2)
        # # self.ui.load_pages.row_3_layout.addWidget(self.icon_button_3)
        # # self.ui.load_pages.row_3_layout.addWidget(self.push_button_1)
        # # self.ui.load_pages.row_3_layout.addWidget(self.push_button_2)
        # # self.ui.load_pages.row_3_layout.addWidget(self.toggle_button)
        # # self.ui.load_pages.row_4_layout.addWidget(self.line_edit)
        # # self.ui.load_pages.row_5_layout.addWidget(self.champions_table_widget)

        # # # RIGHT COLUMN
        # # # ///////////////////////////////////////////////////////////////

        # # # BTN 1
        # # self.right_btn_1 = PyPushButton(
        # #     text="Show Menu 2",
        # #     radius=8,
        # #     color=self.themes["app_color"]["text_foreground"],
        # #     bg_color=self.themes["app_color"]["dark_one"],
        # #     bg_color_hover=self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed=self.themes["app_color"]["dark_four"]
        # # )
        # # self.icon_right = QIcon(Functions.set_svg_icon("icon_arrow_right.svg"))
        # # self.right_btn_1.setIcon(self.icon_right)
        # # self.right_btn_1.setMaximumHeight(40)
        # # self.right_btn_1.clicked.connect(lambda: MainFunctions.set_right_column_menu(
        # #     self,
        # #     self.ui.right_column.menu_2
        # # ))
        # # self.ui.right_column.btn_1_layout.addWidget(self.right_btn_1)

        # # # BTN 2
        # # self.right_btn_2 = PyPushButton(
        # #     text="Show Menu 1",
        # #     radius=8,
        # #     color=self.themes["app_color"]["text_foreground"],
        # #     bg_color=self.themes["app_color"]["dark_one"],
        # #     bg_color_hover=self.themes["app_color"]["dark_three"],
        # #     bg_color_pressed=self.themes["app_color"]["dark_four"]
        # # )
        # # self.icon_left = QIcon(Functions.set_svg_icon("icon_arrow_left.svg"))
        # # self.right_btn_2.setIcon(self.icon_left)
        # # self.right_btn_2.setMaximumHeight(40)
        # # self.right_btn_2.clicked.connect(lambda: MainFunctions.set_right_column_menu(
        # #     self,
        # #     self.ui.right_column.menu_1
        # # ))
        # # self.ui.right_column.btn_2_layout.addWidget(self.right_btn_2)

        # ///////////////////////////////////////////////////////////////
        # END - EXAMPLE CUSTOM WIDGETS
        # ///////////////////////////////////////////////////////////////

    # RESIZE GRIPS AND CHANGE POSITION
    # Resize or change position when window is resized
    # ///////////////////////////////////////////////////////////////
    def resize_grips(self):
        if self.settings["custom_title_bar"]:
            self.left_grip.setGeometry(5, 10, 10, self.height())
            self.right_grip.setGeometry(self.width() - 15, 10, 10, self.height())
            self.top_grip.setGeometry(5, 5, self.width() - 10, 10)
            self.bottom_grip.setGeometry(5, self.height() - 15, self.width() - 10, 10)
            self.top_right_grip.setGeometry(self.width() - 20, 5, 15, 15)
            self.bottom_left_grip.setGeometry(5, self.height() - 20, 15, 15)
            self.bottom_right_grip.setGeometry(self.width() - 20, self.height() - 20, 15, 15)